# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 00:07:23 2024

@author: Boda Li
"""
# Boundary condition for box model
from O2 import O2
from N2 import N2
from Ar import Ar
from Kr import Kr
from math import e

#In this 3-box ocean model, temperature is assumed to decrease uniformly

#temperature decrease from LGM
for i in range(31):
    t_res_cur = 7.5
    t_res_LGM = t_res_cur - 0.1 * i
    t_AABW_cur = -0.9
    t_AABW_LGM = t_AABW_cur - 0.1 * i
    t_NADW_cur = 2.3
    t_NADW_LGM = t_NADW_cur - 0.1 * i
    V_res_cur = 0.45
    V_res_LGM = V_res_cur
    V_AABW_cur = 0.35
    V_AABW_LGM = V_AABW_cur
    V_NADW_cur = 0.20
    V_NADW_LGM = V_NADW_cur
    S_res_cur = 34.7
    S_res_LGM = 35.9
    S_AABW_cur = 34.6
    S_AABW_LGM = 35.8
    S_NADW_cur = 34.9
    S_NADW_LGM = 36.1
    
    global_ocean_volume = 1.335 * 10 ** 18 # m^3 (NOAA National Ocean Service) 
    global_ocean_volume_LGM = 0.965*global_ocean_volume 
    #Ocean volumetric change due to the growth of ice sheet
    
    def density(t, S):
        ## rough estimation
        T = t
        rol = (999.842591 + 6.793952 * 10 ** -2 * T - 9.095290 * 10 ** -3 * T**2 + 1.001685 * 10 ** -4 * T**3 - 1.120083 * 10 ** -6 * T ** 4 + 6.536332 * 10 ** -9 * T **5 
        + S * (8.24493 * 10 ** -1 - 4.0899 * 10 ** -3 * T + 7.6438 * 10 ** -5 * T ** 2 - 8.2467 * 10 ** -7 * T ** 3 + 5.3875 * 10 ** -9 * T ** 4) 
        + S ** 1.5 * (-5.72466 * 10 ** -3 + 1.0227 * 10 ** -4 * T - 1.6546 * 10 ** -6 * T ** 2)+ 4.8314 * 10 ** -4 * S**2 )
        
        return rol
    
    
    #current atmos
    total_air = 1.78 * 10 ** 20 #moles of gas in modern atmosphere
    O2_air = total_air * 0.20946 #wiki
    N2_air = total_air * 0.78084 
    Ar_air = total_air * 0.009340
    Kr_air = total_air * 1.14 * 10 ** -6

    # Gas dissolved in modern ocean
    O2_ocean = global_ocean_volume * ( V_res_cur * density(t_res_cur, S_res_cur) * O2(t_res_cur, S_res_cur) 
                                       + V_AABW_cur * density(t_AABW_cur, S_AABW_cur) * O2(t_AABW_cur, S_AABW_cur)
                                       + V_NADW_cur * density(t_NADW_cur, S_NADW_cur) * O2(t_NADW_cur, S_NADW_cur)) * 10 ** -6 # from umol to mol
    
    N2_ocean = global_ocean_volume * ( V_res_cur * density(t_res_cur, S_res_cur) * N2(t_res_cur, S_res_cur) 
                                       + V_AABW_cur * density(t_AABW_cur, S_AABW_cur) * N2(t_AABW_cur, S_AABW_cur)
                                       + V_NADW_cur * density(t_NADW_cur, S_NADW_cur) * N2(t_NADW_cur, S_NADW_cur)) * 10 ** -6 # from umol to mol
    
    Ar_ocean = global_ocean_volume * ( V_res_cur * density(t_res_cur, S_res_cur) * Ar(t_res_cur, S_res_cur) 
                                       + V_AABW_cur * density(t_AABW_cur, S_AABW_cur) * Ar(t_AABW_cur, S_AABW_cur)
                                       + V_NADW_cur * density(t_NADW_cur, S_NADW_cur) * Ar(t_NADW_cur, S_NADW_cur)) * 10 ** -6 # from umol to mol
    
    Kr_ocean = global_ocean_volume * ( V_res_cur * density(t_res_cur, S_res_cur) * Kr(t_res_cur, S_res_cur) 
                                       + V_AABW_cur * density(t_AABW_cur, S_AABW_cur) * Kr(t_AABW_cur, S_AABW_cur)
                                       + V_NADW_cur * density(t_NADW_cur, S_NADW_cur) * Kr(t_NADW_cur, S_NADW_cur)) * 10 ** -6 # from umol to mol
    # Calculate the total amount
    O2_total = O2_air + O2_ocean
    N2_total = N2_air + N2_ocean
    Ar_total = Ar_air + Ar_ocean
    Kr_total = Kr_air + Kr_ocean
    
    # LGM
    # Pressure change due to topographic change
    p_LGM = e ** (120/7600)
    
    #  Dissolved gas in LGM ocean
    O2_ocean_LGM = p_LGM * global_ocean_volume_LGM * ( V_res_LGM * density(t_res_LGM, S_res_LGM) * O2(t_res_LGM, S_res_LGM) 
                                       + V_AABW_LGM * density(t_AABW_LGM, S_AABW_LGM) * O2(t_AABW_LGM, S_AABW_LGM)
                                       + V_NADW_LGM * density(t_NADW_LGM, S_NADW_LGM) * O2(t_NADW_LGM, S_NADW_LGM)) * 10 ** -6 # from umol to mol
    N2_ocean_LGM = p_LGM * global_ocean_volume_LGM * ( V_res_LGM * density(t_res_LGM, S_res_LGM) * N2(t_res_LGM, S_res_LGM) 
                                       + V_AABW_LGM * density(t_AABW_LGM, S_AABW_LGM) * N2(t_AABW_LGM, S_AABW_LGM)
                                       + V_NADW_LGM * density(t_NADW_LGM, S_NADW_LGM) * N2(t_NADW_LGM, S_NADW_LGM)) * 10 ** -6 # from umol to mol
    Ar_ocean_LGM = p_LGM * global_ocean_volume_LGM * ( V_res_LGM * density(t_res_LGM, S_res_LGM) * Ar(t_res_LGM, S_res_LGM) 
                                       + V_AABW_LGM * density(t_AABW_LGM, S_AABW_LGM) * Ar(t_AABW_LGM, S_AABW_LGM)
                                       + V_NADW_LGM * density(t_NADW_LGM, S_NADW_LGM) * Ar(t_NADW_LGM, S_NADW_LGM)) * 10 ** -6 # from umol to mol
    Kr_ocean_LGM = p_LGM * global_ocean_volume_LGM * ( V_res_LGM * density(t_res_LGM, S_res_LGM) * Kr(t_res_LGM, S_res_LGM) 
                                       + V_AABW_LGM * density(t_AABW_LGM, S_AABW_LGM) * Kr(t_AABW_LGM, S_AABW_LGM)
                                       + V_NADW_LGM * density(t_NADW_LGM, S_NADW_LGM) * Kr(t_NADW_LGM, S_NADW_LGM)) * 10 ** -6 # from umol to mol
    
    
    O2_air_LGM = O2_total - O2_ocean_LGM
    N2_air_LGM = N2_total - N2_ocean_LGM
    Ar_air_LGM = Ar_total - Ar_ocean_LGM
    Kr_air_LGM = Kr_total - Kr_ocean_LGM
    total_air_LGM = O2_air_LGM + N2_air_LGM + Ar_air_LGM 
    
    #Result
    
    print("temperature decrease from baseline" + " " + str(0.1 * i) +  "Celcius")
    print("N2 atm")
    print(N2_air)
    print("dAr/N2")
    print((Ar_air_LGM/N2_air_LGM/ (Ar_air/N2_air) - 1) * 1000)
    print("dKr/N2")
    print((Kr_air_LGM/N2_air_LGM/ (Kr_air/N2_air) - 1) * 1000)