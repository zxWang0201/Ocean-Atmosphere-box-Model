# -*- coding: utf-8 -*-
"""
Created on Fri Apr 12 00:07:45 2024

@author: Boda Li
"""
import numpy as np
def Kr(t, S):
    '''
    Weiss, R.F.; Kyser, T.K. Solubility of krypton in water and sea water.
    J. Chem. Eng. Data 1978, 23, 69–72, https://doi.org/10.1021/je60076a014.

    t in celcius
    S in per mil
    return umol/kg
    '''
    T = t + 273.15
    # ml/kg
    C = np.exp(-112.6840 +  153.5817 *(100/ T) + 74.4690 * np.log(T/100) -10.0189 * (T/100) + S * (-0.011213 -0.001844 * T/100 + 0.0011201 * (T/100)**2))
    return C * 101325/8.314/273.15/0.997  # ml -> * 10 ^ -6 m^3 -> umol * 10^ 6, considering non-ideality

