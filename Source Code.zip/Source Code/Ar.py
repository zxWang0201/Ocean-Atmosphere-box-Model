# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 00:02:13 2024

@author: Boda Li
"""
import numpy as np
def Ar(t, S):
    '''
    Roberta C. Hamme, Steven R. Emerson,
    solubility of neon, nitrogen and argon in distilled water and seawater,
    Deep Sea Research Part I: Oceanographic Research Papers,
    Volume 51, Issue 11,
    2004,
    Pages 1517-1528,
    ISSN 0967-0637,
    https://doi.org/10.1016/j.dsr.2004.06.009.

    t in celcius
    S in per mil
    return umol/kg
    '''
    Ts = np.log((298.15 - t)/(273.15 + t))
    return np.exp(2.79150 + 3.17609 * Ts + 4.13116 * Ts ** 2 + 4.90379 * Ts ** 3 + S * (-6.96233 * 10 ** -3 - 7.66670 * 10 ** -3 * Ts - 1.16888 * 10 ** -2 * Ts **2))