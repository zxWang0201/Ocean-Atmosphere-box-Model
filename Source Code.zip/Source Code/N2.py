# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 23:37:54 2024

@author: Boda Li
"""
import numpy as np
def N2(t, S):
    '''
    Roberta C. Hamme, Steven R. Emerson,
    solubility of neon, nitrogen and argon in distilled water and seawater,
    Deep Sea Research Part I: Oceanographic Research Papers,
    Volume 51, Issue 11,
    2004,
    Pages 1517-1528,
    ISSN 0967-0637,
    https://doi.org/10.1016/j.dsr.2004.06.009.

    t in celcius
    S in per mil
    return umol/kg
    '''
    Ts = np.log((298.15 - t)/(273.15 + t))
    return np.exp(6.42931 + 2.92704 * Ts + 4.32531 * Ts ** 2 + 4.69149 * Ts ** 3 + S * (-7.44129 * 10 ** -3 - 8.02566 * 10 ** -3 * Ts - 1.46775 * 10 ** -2 * Ts **2))