# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 22:57:41 2024

@author: Boda Li
"""
import numpy as np
def O2(t, S):
    '''
    F. H. Garcia and I. I. Gordon, “Oxygen Solubility in Seawater: Better Fitting Equations,”
    Limnology and Oceanography, Vol. 37, No. 6, 1992, pp. 1307-1312. doi:10.4319/lo.1992.37.6.1307

    t in celcius
    S in per mil
    return umol/kg
    '''
    Ts = np.log((298.15 - t)/(273.15 + t))
    return np.exp(5.80818 + 3.20684 * Ts + 4.11890 * Ts**2 + 4.93845 * Ts**3 + 1.01567 * Ts ** 4 + 1.41575 * Ts ** 5 
                  + S * (-7.01211 * 10 ** -3 - 7.25958  * 10 ** -3 * Ts - 7.93334 * 10 ** -3 * Ts ** 2 - 5.54491 * 10 ** -3  * Ts ** 3) 
                  - 1.32412 * 10 ** -7 * S ** 2)
    

